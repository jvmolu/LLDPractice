package splitwise.expenses;

public class AbsoluteExpense extends Expense{
    public AbsoluteExpense(String type, double amount) {
        super(type, amount);
    }

}
